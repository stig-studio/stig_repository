
-- ������� �� 5 ����������� � ��� ��� �����������

--alter table tbl_order_details
--add date_sale datetime not null

	--id int identity not null primary key,
	--product nvarchar(50) not null,
	--quantity_prod int not null,

--===========================================================================

use [C:\DEVMED\SAMPLES\WPF\DYNAMICLISTVIEW\DATA\NORTHWIND.MDF];

create table EventLogByOrderDetails(

	id int identity not null primary key,
	product nvarchar(50) not null,
	quantity_prod int not null,
	date_sale datetime not null
)


go
create trigger TriggerOrderDetails on
[Order Details]
for insert, update
as
begin
	declare @product nvarchar(50)
	declare @quantity_prod int
	declare @date_sale datetime

	select @product = prd.ProductName from dbo.Products prd
	inner join
	dbo.[Order Details] od on od.ProductID = prd.ProductID
	inner join
	dbo.Orders o on o.OrderID = od.OrderID
	inner join
	dbo.Employees emp on emp.EmployeeID = o.EmployeeID
	where emp.ReportsTo = 5 or emp.EmployeeID = 5

	--================================================================================	

	select @quantity_prod = od.Quantity from dbo.[Order Details] od
	inner join
	dbo.Orders o on o.OrderID = od.OrderID
	inner join
	dbo.Employees em on em.EmployeeID = o.EmployeeID
	where em.ReportsTo = 5 or em.EmployeeID = 5 and od.ProductID in(
		select p.ProductID
		from dbo.Products p
		where p.ProductName like @product
	)

	--================================================================================

	select @date_sale = o.OrderDate from dbo.Orders o
	inner join
	dbo.Employees emp on emp.EmployeeID = o.EmployeeID
	where emp.ReportsTo = 5 or emp.EmployeeID = 5

	--================================================================================

	insert into EventLogByOrderDetails values( @product, @quantity_prod, @date_sale )

end;

insert into dbo.Orders values( 'AROUT', 9, getdate(), getdate(), null, 2, 44.21, 'test', 'test', 'test', null, 545121, 'USA' );
insert into dbo.[Order Details] values( 11082, 10.00, 25, 5, 0.15 );