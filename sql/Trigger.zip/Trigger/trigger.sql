use [C:\DEVMED\SAMPLES\WPF\DYNAMICLISTVIEW\DATA\NORTHWIND.MDF]

create table journal_event (
	
	id int primary key identity not null,
	login_name nvarchar(50) not null,
	event_time datetime not null,
	event_type nvarchar(50),
	SQLCommand nvarchar(200)

)

go
create trigger journal_db
on database
for DDL_TABLE_EVENTS
as
begin
	declare @data xml
	declare @login nvarchar(50)
	declare @eventTime datetime
	declare @eventType nvarchar(50)
	declare @sqlCmd nvarchar(200)
	
	set @data		= EVENTDATA()
	set @login		= SYSTEM_USER
	set @eventTime	= GETDATE()
	set @eventType	= @data.value('(/EVENT_INSTANCE/ObjectType)[1]', 'nvarchar(2000)');
	set @sqlCmd		= @data.value('(/EVENT_INSTANCE/TSQLCommand)[1]', 'nvarchar(2000)');

	insert into journal_event values( @login, @eventTime, @eventType, @sqlCmd )
	
end;

create table Test (
	
	id int primary key identity,
	fio nvarchar(50) not null,
	dob datetime not null,
	phone nvarchar not null
)

drop table Test